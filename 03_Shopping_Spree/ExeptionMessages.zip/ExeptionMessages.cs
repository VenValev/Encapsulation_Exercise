﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03_Shopping_Spree
{
    public abstract class ExeptionMessages
    {
        public const string invalidName = "Name cannot be empty";
        public const string invalidMoney = "Money cannot be negative";
    }
}
